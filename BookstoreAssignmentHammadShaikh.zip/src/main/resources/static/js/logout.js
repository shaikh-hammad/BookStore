document.getElementById('logoutLink').addEventListener('click', function() {
    document.getElementById('logoutForm').submit();
});